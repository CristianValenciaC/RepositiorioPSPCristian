#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

int contarNumerosImpares(int numeros[], int tamano)
{
    int contador = 0;
    int i;
    for(i = 0; i < tamano; i++)
    {
        if(numeros[i]%2!=0){
            contador+=1;
        }
    }

    return contador;
}

int mediaNumerosImpar(int numerosImpar[], int tamano){
    int media = 0;
    int i;

    for(i = 0; i < tamano; i++)
    {
        media += numerosImpar[i];
    }

    return media/tamano;
}

void main()
{
    int fd[2];
    int fd2[2];
    int fd3[2];
    pid_t hijo;

    int buffer[4];
    int buffer2;
    int buffer3;

    pipe(fd);
    pipe(fd2);
    pipe(fd3);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[1]);
        close(fd2[0]);
        close(fd3[1]);
        int num1, num2, num3, num4;
        printf("Introduce número:");
        scanf("%d",&num1);
        printf("Introduce número:");
        scanf("%d",&num2);
        printf("Introduce número:");
        scanf("%d",&num3);
        printf("Introduce número:");
        scanf("%d",&num4);
        int numeros[] = {num1, num2, num3, num4};
        write(fd2[1], &numeros, sizeof(numeros));
        read(fd[0], &buffer2, sizeof(buffer2));
        printf("Se han procesado %d numeros impares", buffer2);
        read(fd3[0], &buffer3, sizeof(buffer3));
        printf("\nLa media aritmetica = %d\n", buffer3);
    }
    else
    {
        close(fd[0]);
        close(fd2[1]);
        close(fd3[0]);
        read(fd2[0], &buffer, sizeof(buffer));
        int tamano = 4;
        int numImpar = contarNumerosImpares(buffer,tamano);
        write(fd[1], &numImpar, sizeof(numImpar));
        int media;
        if (numImpar == 0)
        {
            media = 0;
        }
        else
        {
            int numerosImpares[numImpar];
            int i = 0, j;
            for (j = 0; j < tamano; j++)
            {
                if (buffer[j]%2!=0)
                {
                    numerosImpares[i]=buffer[j];
                    i++;
                }
                
            }

            media = mediaNumerosImpar(numerosImpares, numImpar);
            
        }
        write(fd3[1], &media, sizeof(media));
        wait(NULL);
    }
    
}