import java.util.ArrayList;

public class Refineria {
    public static void main(String[] args) {
        //ArrayList de productores y de consumidores
        ArrayList<Productor> listaProductores = new ArrayList<Productor>();
        ArrayList<Camion> listaCamion = new ArrayList<Camion>();
        //Crear el deposito para que rellene a los camiones
        Deposito depositoPrinicipal = new Deposito();
        //Crear el productor que va a generar litros y que se almacenará en el depósito
        int numProductores = (int)Math.random()*100 + 1;
        for(int i = 1; i<numProductores; i++){
            listaProductores.add(new Productor(depositoPrinicipal, i));
        }
        //Crear los camiones para almacenar los litros de los depositos que estaban almacenados
        int numCamiones = (int)Math.random()*100 + 1;
        for(int i = 0; i < numCamiones; i++){
            listaCamion.add(new Camion(depositoPrinicipal, i));
        }

        //Comienzo de ejecuion de los hilos
        int posicion = 0;
        while(posicion != -1){
            try {
                listaProductores.get(posicion).start();
                listaCamion.get(posicion).start();
            } catch (Exception e) {
                if(listaCamion.size()==posicion && listaProductores.size() > posicion){
                    int posicionProductores = posicion;
                    while(posicionProductores != -1){
                        try {
                            listaProductores.get(posicionProductores).start();
                        } catch (Exception ex) {
                            posicionProductores = -1;
                        }
                    }
                }else if(listaCamion.size()>posicion && listaProductores.size() == posicion){
                    int posicionCamiones = posicion;
                    while(posicionCamiones != -1){
                        try {
                            listaProductores.get(posicionCamiones).start();
                        } catch (Exception ex) {
                            posicionCamiones = -1;
                        }
                    }
                }
                posicion = -1;
            }
        }
    }
}
