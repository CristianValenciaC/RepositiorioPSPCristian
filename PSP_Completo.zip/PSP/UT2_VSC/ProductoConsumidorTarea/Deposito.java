public class Deposito {
    private double litrosdeposito;
    private boolean disponible = false;

    //método realiza llenado depósito del camión
    public synchronized double llenarDepositoCamion(int n) {
        while (!disponible) {
        try {
            wait();
        } catch (InterruptedException e) { }
        }
    //Una vez hay valor disponible se devuelve el valor del deposito
        System.out.println("Camión " + n + " carga: " + litrosdeposito + " Litros");
        disponible = false;
        notify();
        return litrosdeposito;
    }
    //método productor llena el depósito
    public synchronized void prodLlenaDep(int numproductor, double litros) {
        while (disponible){
    	    try {
    	          wait();
    	    } catch (InterruptedException e) { }
    	  }
          //Una vez cuando no haya contenido en el deposito, se vuelve a llenar
          System.out.println("Productor " + numproductor + " llena el depósito con => " + litros + " Litros");
    	  litrosdeposito = litros;
    	  disponible = true;
    	  notify();
    }
}
