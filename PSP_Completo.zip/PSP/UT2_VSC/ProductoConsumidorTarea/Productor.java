// Clase Productor
public class Productor extends Thread {
    /*El Hilo Productor “llenará” el depósito generando números aleatorios entre 0 y 1000 (representa litros
de combustible). Se realizarán 15 llenados del depósito
 */
    private Deposito dep;
    private int numProductor;
    
    //Constructor clase productor
    public Productor(Deposito dep, int numProductor){
        this.dep = dep;
        this.numProductor = numProductor;
    }

    public void run(){
        for(int i = 1; i<=15; i++){
            Double litros = Math.floor(Math.random()*1000);
            dep.prodLlenaDep(numProductor, litros);
            try {
                sleep(100);
            } catch (InterruptedException e) { 
                
            }
        }
    }
   
}