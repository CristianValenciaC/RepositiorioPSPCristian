public class Refineria {
    public static void main(String[] args) {
        //Crear el deposito para que rellene a los camiones
        Deposito depositoPrinicipal = new Deposito();
        //Crear el productor que va a generar litros y que se almacenará en el depósito
        Productor producir = new Productor(depositoPrinicipal);
        //Crear los camiones para almacenar los depositos que estaban almacenados
        Camion camion1 = new Camion(depositoPrinicipal, 1);
        Camion camion2 = new Camion(depositoPrinicipal, 2);
        Camion camion3 = new Camion(depositoPrinicipal, 3);

        //Comienzo de ejecuion de los hilos
        producir.start();
        camion1.start();
        camion2.start();
        camion3.start();
    }
}
