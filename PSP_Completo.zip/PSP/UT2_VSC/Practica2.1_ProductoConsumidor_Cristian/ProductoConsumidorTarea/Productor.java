// Clase Productor
public class Productor extends Thread {
    /*El Hilo Productor “llenará” el depósito generando números aleatorios entre 0 y 1000 (representa litros
de combustible). Se realizarán 15 llenados del depósito
 */
    private Deposito dep;
    
    //Constructor clase productor
    public Productor(Deposito dep){
        this.dep = dep;
    }

    public void run(){
        for(int i = 1; i<=15; i++){
            Double litros = Math.floor(Math.random()*1000);
            dep.prodLlenaDep(litros);
            try {
                sleep(100);
            } catch (InterruptedException e) { 
                
            }
        }
    }
   
}