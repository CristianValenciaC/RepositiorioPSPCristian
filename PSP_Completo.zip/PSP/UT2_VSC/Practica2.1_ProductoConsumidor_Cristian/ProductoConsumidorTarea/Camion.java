public class Camion extends Thread {
    //Constructor clase camión: n -> número de camión
    private Deposito dep;
    private int n;
    private double litros;
    
    public Camion (Deposito dep, int n){
        this.dep = dep;
        this.n = n;
    }
    public void run(){
        double litrosFinal = 0;
        for(int i = 0; i < 5; i++){//Almacena hasta 5 veces la cantidad de litros en cada deposito
            litros = dep.llenarDepositoCamion(n);
            litrosFinal += litros;
        }

        System.out.println("Camión " + n + " => Volumen Total Recogido = " + litrosFinal + " Litros" +" Operación carga finalizada!!");
    }
}
