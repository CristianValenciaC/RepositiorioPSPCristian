#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>

int main(void)
{
  int  fp;
  int  p,  bytesleidos;
  int contador = 0;
  int i;
  int contadorPalabras = 0;
  char buffer[10];

   p=mkfifo("FIFODAM",  S_IFIFO|0666);//permiso  de  lecture y escritura
	
  while (1)
  {
	fp = open("FIFODAM", 0);
	bytesleidos=read(fp,buffer,1);

    printf("OBTENIENDO  Informacion...");

	while 	(bytesleidos!=0)
	{
	   printf("%c",buffer[0]);
       if (!(isdigit(buffer[0])))
       {
        /* code */
        contador += 1;
       }
        contadorPalabras +=1;
        
	   bytesleidos=read(fp,buffer,1)	;//leo  otro  byte
	}

    if (contador > 0) 
    {
        if (contador > 2 && contador < contadorPalabras)
    {
        /* code */
        printf("Esta frase esta compuesto de numeros y letras\n");
        contador = 0;
        contadorPalabras = 0;
    }
    else
    {
        printf("Esta frase esta compuesto de letras\n");
        contador = 0;
        contadorPalabras = 0;
    }
        
    }
    
    else
    {
        printf("Esta frase esta compuesto de numeros\n");
        contador = 0;
        contadorPalabras = 0;
    }
    
    
	close(fp); 
  }  
return(0); 
}