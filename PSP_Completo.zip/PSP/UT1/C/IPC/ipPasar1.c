#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h> 
#include <string.h>

void main(){

     /*Array para almacenar descriptores del fichero*/
     int fd[2];
     int fd2[2];
     char buffer[30];
     char letrasNIF[] = "TRWAGMYFPDXBNJZSQVHLCKE";
     pid_t pid;
    
     // Creamos el pipe
     pipe(fd);
     pipe(fd2);
     
     //Se crea un proceso hijo
     pid = fork();

     if (pid==0)
     
     {
                close(fd[0]);
                close(fd2[1]);
                int valor;
                char contenido[8];
                printf("Introduce el número de tu dni: ");
                scanf("%d", &valor);
                sprintf(contenido, "%d" ,valor);
                
                write(fd[1], contenido, 10);
                read(fd2[0], buffer, 10);
                printf("La letra del NIF es: %s", buffer);
     
     }
     
     else
     
     {
                close(fd[1]);// Cierra el descriptor de lectura
                read(fd[0], buffer, 10);
                int DNI = atoi(buffer);
                char resultado[1];
                resultado[0] = letrasNIF[DNI%23];
                close(fd2[0]);
                write(fd2[1], resultado, 10);
                wait(NULL);
     }
     
        
}