#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h> 
#include <string.h>
#include <time.h>

int  main()
{
   int  fp;
   char  saludo[]= "1000293";
	
    fp = open("FIFODAM",1);

    printf("Mandando  informacion  al  FIFO...\n"); 
    write(fp,saludo,strlen(saludo));
   close(fp);
   return 0;
}