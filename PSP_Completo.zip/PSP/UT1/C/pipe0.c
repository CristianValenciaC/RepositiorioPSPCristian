#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h> 

void main(){

     /*Array para almacenar descriptores del fichero*/
     int fd[2]; 
     char buffer[30];
     pid_t pid;
    
     // Creamos el pipe
     pipe(fd); 
     
     //Se crea un proceso hijo
     pid = fork();

     if (pid==0)
     
     {
                /*close(fd[1]); // Cierra el descriptor de escritura
                printf("El hijo se dispone a leee del PIPE \n");
                read(fd[0], buffer, 10);
                printf("\t Mensaje leido del pipe: %s \n", buffer);*/
                close(fd[0]);
                printf("El hijo va a escribir");
                write(fd[1], "Hola papa", 10);
     
     }
     
     else
     
     {
                close(fd[1]); // Cierra el descriptor de lectura
                printf("El padre va a leer el mensaje de PIPE...\n");
                read(fd[0], buffer, 10);
                printf("\t Mensaje leído del pipe: %s \n", buffer);
     }
     
        
}