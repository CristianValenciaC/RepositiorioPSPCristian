#include <stdio.h>
#include <stdlib.h>

int main()
{
/*system pertenece a la libreria <stdlib.h>*/
	printf("Inicio del programa\n");
	system("ps -l");
	printf("Fin del programa\n");
}

