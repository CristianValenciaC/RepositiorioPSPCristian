#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void main()
{

	printf("Inicio del Programa\n");
	system("ps -l");
	int dormir;
	for (dormir = 0; dormir < 10; dormir++ ) {
	
	printf("El programa esta descansando\n");
	sleep(dormir);
	}
	
	execl("/usr/bin/calc", "calc", "15*20", NULL);
	printf("Fin del programa\n");
}
