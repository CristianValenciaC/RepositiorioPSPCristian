#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

void main() {
  pid_t pid, pid_hijo;
  
  
  // Se crea un proceso hijo, la función fork() devuelve:
  // un valor negativo -> si se produce cualquier error
  // 0 -> si estamos en el proceso hijo
  // un valor positivo (pid del hijo) -> si estamos en el proceso padre
  // proceso padre
  
  
  pid = fork(); 
  printf("El pid del proceso hijo es %d\n", getpid());
  printf("El ppid del proceso padre es %d\n", getppid()); 
  pid = fork(); 
  printf("Hola 1\n"); 
  printf("Hola 2\n");  
}
