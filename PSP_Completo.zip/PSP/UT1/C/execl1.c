#include <stdio.h>
#include <unistd.h>

int main()
{
/*exec pertenece a la libreria <unistd.h>*/
	printf("Inicio del programa\n");
	execl("/usr/bin/ps", "ps", "-l", NULL);
	printf("Fin del programa\n");
}
