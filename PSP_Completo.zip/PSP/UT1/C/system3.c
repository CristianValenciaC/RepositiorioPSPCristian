#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


void main()
{
	printf("Inicio del programa\n");
	int tiempo = 10;
	system("calc 20+5*10");
	sleep(tiempo);
	system("ps -l");
	printf("Fin del programa\n");
}
