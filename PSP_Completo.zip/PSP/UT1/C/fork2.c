#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

void main() {
  
  //Se definen 2 varialbles de tipo pid_t para almacenar los pids de los procesos
  pid_t pid, pid_hijo;
  
  // Se crea un proceso hijo, la función fork() devuelve:
  // un valor negativo -> si se produce cualquier error
  // 0 -> si estamos en el proceso hijo
  // un valor positivo (pid del hijo) -> si estamos en el proceso padre
  // proceso padre
  
  pid = fork(); /*Llega esta linea y se crea un proceso hijo, que se ejucta
  primero el hijo hasta el final del código, una vez acabado el proceso del hijo, vuelve
  al proceso padre y se ejecuta*/
  
  //Tabla procesos, cuando un proceso se elimina, su pid, puede ser reutilizado.
  
  if (pid == 0)
  	{
  		/*estamos en el proceso hijo*/
  		fork();
  		wait(NULL);
  		printf("Soy el hijo y mi pid es:  %d\n" ,getpid());
  		printf("Mi padre es el proceso es: %d\n", getppid()); 
  	}
  else
  	{
  		/*estamos en el proceso padre*/
  		wait(NULL); //Indica que espere el procesador padre
  		printf("Soy el padre y mi pid es:  %d\n", getpid());
  		printf("Mi padre es el proceso es: %d\n", getppid()); 
  	}
  	
  exit(0);

}
