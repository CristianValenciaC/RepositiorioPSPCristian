import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class SocketUDPServerIP{

    public static void main(String[] args) throws Exception{

        //Creacion del DatagramSocket para la conexión a partir de un puerto para que puedan enviar o recibir
        //paquetes
        DatagramSocket socket = new DatagramSocket(20010);

        System.out.println("Socket Servidor esperando datagrama");
		//creacion de un paquete que recibe el paquete que se ha enviado por el puerto
        DatagramPacket recibo;
        //Bucle que realiza lectura de mensajes hasta que se cierre el socket
        while(socket.isClosed() == false){
            byte[] buffer = new byte[1024]; // variable para recibir el datagrama enviado desde cliente
            recibo = new DatagramPacket(buffer, buffer.length);
            socket.receive(recibo);

            String mensaje = new String(recibo.getData()).trim();// obtengo String

            //El servidor revisa si el mensaje recibido es 0.0.0.0
            if(mensaje.trim().equals("0.0.0.0")){
                System.out.println("IP Recibida:" + mensaje);
                socket.close();
                System.out.println("El servidor ha cerrado correctamente");
            }else{
                System.out.println("IP Recibida:" + mensaje);

                //Comprueba durante el proceso se cumpla con lo requerido
                int resultado = 0;
                //Crea un array de String a partir de un separador que es el punto(.)
                String[] numIp = mensaje.split("\\.");
                //Comprueba si cumple con el tamaño del string que representa una IP
                if(numIp.length != 4){
                    resultado = -1;
                }

                //Declarar elementos para recorrer el array y los char del texto
                int posicion = 0;
                int recorrerString = 0;
                String binario = "";
                                
                while(posicion < numIp.length && resultado != -1){
                    if(Character.isDigit(numIp[posicion].charAt(recorrerString))==false){ //Comprueba si no es un digito
                        resultado = -1;
                    }else{
                        recorrerString++;
                        if(recorrerString == numIp[posicion].length()){//comprueba si ha llegado a la longuitud del string
                            int numero = Integer.parseInt(numIp[posicion]);
                            if(numero <= 255 && numero >= 0){//comprueba si el numero está entre esos campos
                                binario += Integer.toBinaryString(numero);//convierte el numero en un BinarioString
                                if(posicion < numIp.length -1){
                                    binario += ".";
                                }
                                //Siguiente posicion y reinicio contador String
                                posicion++;
                                recorrerString = 0;
                            }else{
                                resultado = -1;
                            }
                            
                        }
                    }
                }

                //Recogemos la ip y el puerto de donde ha recibido este paquete
                InetAddress IPOrigen = recibo.getAddress();
                int puerto = recibo.getPort();
                byte[] numeroBinario;

                //comprueba que no ha habido ningun error y que tenga longitud
                if(resultado == 0 && binario.length() != 0){
                    //en caso de que todo está correcto, se enviará el texto en binario
                    numeroBinario = new byte[1024];
                    numeroBinario = binario.getBytes();
                    DatagramPacket envio = new DatagramPacket(numeroBinario, numeroBinario.length, IPOrigen, puerto);
                    socket.send(envio);
                }else{
                    //En caso de que ha habido error, se envia un paquete vacío
                    numeroBinario = new byte[0];
                    DatagramPacket envio = new DatagramPacket(numeroBinario, numeroBinario.length, IPOrigen, puerto);
                    socket.send(envio);
                }
            }
        }
    }
}