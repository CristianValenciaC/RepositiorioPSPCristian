import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class SocketUDPServerIP_old{

    public static void main(String[] args) throws Exception{

        DatagramSocket socket = new DatagramSocket(20010);

        System.out.println("Socket Servidor esperando datagrama");
		DatagramPacket recibo;

        while(socket.isClosed() == false){
            byte[] buffer = new byte[1024]; // para recibir el datagrama
            recibo = new DatagramPacket(buffer, buffer.length);
            socket.receive(recibo);

            String mensaje = new String(recibo.getData()).trim();// obtengo String

            if(mensaje.trim().equals("0.0.0.0")){
                System.out.println("El servidor ha cerrado correctamente");
                socket.close();
            }else{
                System.out.println("IP Recibida:" + mensaje);

                int resultado = 0;

                int[] numeroPing = new int[4];
                int posicion = numeroPing.length - 1;
                int aumento = 1;
                int recorrerString = mensaje.length() -1;
                
                while(resultado == 0 && recorrerString >= 0){
                    if(Character.isDigit(mensaje.charAt(recorrerString))){
                        numeroPing[posicion] += Character.getNumericValue(mensaje.charAt(recorrerString)) * aumento;
                        aumento *= 10;
                    }
                    
                    if(mensaje.charAt(recorrerString) == '.' || recorrerString == 0){
                        if(numeroPing[posicion] <= 255 && numeroPing[posicion] >= 0){
                            if(posicion - 1 == -1){
                                resultado = -1;
                            }else{
                                posicion -= 1;
                            }
                            aumento = 1;
                        }else{
                            resultado = -1;
                        }
                    }

                    recorrerString--;
                }

                String binario = "";
                if(resultado == 0){
                    for(int i = 0; i < numeroPing.length; i++){
                        if(i == numeroPing.length-1){
                            binario += Integer.toBinaryString(numeroPing[i]);
                        }else{
                            binario += Integer.toBinaryString(numeroPing[i]) + ".";
                        }
                    }
                }

                InetAddress IPOrigen = recibo.getAddress();
                int puerto = recibo.getPort();

                if(resultado == 0 && binario.length() != 0){
                    byte[] numeroBinario = new byte[1024];
                    numeroBinario = binario.getBytes();
                    DatagramPacket envio = new DatagramPacket(numeroBinario, numeroBinario.length, IPOrigen, puerto);
                    socket.send(envio);
                }else{
                    byte[] vacio = new byte[0];
                    DatagramPacket envio = new DatagramPacket(vacio, vacio.length, IPOrigen, puerto);
                    socket.send(envio);
                }
            }
        }
    }
}