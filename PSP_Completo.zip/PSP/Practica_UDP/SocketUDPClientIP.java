import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;


public class SocketUDPClientIP {

    private static Scanner sc;

    public static void main(String[] args) throws Exception{
        
        sc = new Scanner(System.in);

        DatagramSocket clientSocket = new DatagramSocket();// socket cliente

        // DATOS DEL SERVIDOR al que enviar mensaje
		InetAddress IPServidor = InetAddress.getLocalHost();// localhost
		int puerto = 20010; // puerto por el que escucha
        byte[] mensaje = new byte[1024]; //Array almacenar mensaje  

        System.out.println("Introduce una IP en formato decimal");
        String direccionIP = sc.next();
        mensaje = direccionIP.getBytes();
        System.out.println("Socket Cliente envía IP " + direccionIP);

        // ENVIANDO DATAGRAMA AL SERVIDOR
		DatagramPacket envio = new DatagramPacket(mensaje, mensaje.length, IPServidor, puerto);
		clientSocket.send(envio);

        if(direccionIP.equals("0.0.0.0")){
            System.out.println("El cliente ha mandado una peticion de cierre del servidor");
            clientSocket.close();
        }else{
        // RECIBIENDO DATAGRAMA DEL SERVIDOR
		byte[] recibidos = new byte[1024];
		DatagramPacket recibo = new DatagramPacket(recibidos, recibidos.length);
		clientSocket.receive(recibo);

        String recibido = new String(recibo.getData()).trim();// obtengo String
        System.out.println("Socket Servidor .........");
        if (recibido.isEmpty()) {
            System.out.println("IP " + direccionIP + " es una IP no valida");
        }else{
            System.out.println("IP " + direccionIP + " en binario = " + recibido);
        }

        clientSocket.close();
        }   
    }
    
}
