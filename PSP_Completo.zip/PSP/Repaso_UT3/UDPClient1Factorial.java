import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient1Factorial {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int puerto = 54321;

        try {
            DatagramSocket conexionCliente = new DatagramSocket();

            byte[] buffer = new byte[1024];

            InetAddress servidor = InetAddress.getLocalHost();

            System.out.println("Mandando mensaje de conexión");
            String cliente = "cliente1";

            byte[] mensajeConfirmacion = new byte[1024];
            mensajeConfirmacion = cliente.getBytes();

            DatagramPacket paqueteConfirmacion = new DatagramPacket(mensajeConfirmacion, mensajeConfirmacion.length, servidor, puerto);
            conexionCliente.send(paqueteConfirmacion);

            DatagramPacket reciboConfirmacion = new DatagramPacket(buffer, buffer.length);
            conexionCliente.receive(reciboConfirmacion);

            buffer = new byte[1024];

            String contenido = new String(reciboConfirmacion.getData());

            System.out.println(contenido);
            
            System.out.println("Escribe un numero para mandar al servidor");
            int numero = sc.nextInt();
            String numeroTexto = String.valueOf(numero);
            System.out.println(numeroTexto);

            System.out.println("Enviando numero al servidor");
            byte[] mensajeNumero = numeroTexto.getBytes();
            DatagramPacket numeroServidor = new DatagramPacket(mensajeNumero, mensajeNumero.length, servidor, puerto);
            conexionCliente.send(numeroServidor);

            System.out.println("Recibiendo numero del servidor");
            DatagramPacket reciboConfirmacionFactorial = new DatagramPacket(buffer, buffer.length);
            conexionCliente.receive(reciboConfirmacionFactorial);
            String factorial = new String(reciboConfirmacionFactorial.getData()).trim();
            int numFinal = Integer.parseInt(factorial);
            
            System.out.println("Numero factorial de " + numero + " = " + numFinal);

            System.out.println("Cerrando la conexión con el cliente");
            sc.close();
            conexionCliente.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
