import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class TCPClient1Factorial {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String host = "localhost";
        int puerto = 54321;

        try {
            Socket conexionSocket = new Socket(host, puerto);
            System.out.println("Mandando mensaje de conexión");
            String cliente = "cliente1";

            DataOutputStream mensaje = new DataOutputStream(conexionSocket.getOutputStream());
            mensaje.writeUTF(cliente);

            DataInputStream recibo = new DataInputStream(conexionSocket.getInputStream());
            String contenido = recibo.readUTF();

            System.out.println(contenido);
            
            System.out.println("Escribe un numero para mandar al servidor");
            int numero = sc.nextInt();

            System.out.println("Enviando numero al servidor");
            mensaje.writeInt(numero);

            System.out.println("Recibiendo numero del servidor");
            int numFinal = recibo.readInt();

            System.out.println("Numero factorial de " + numero + " = " + numFinal);

            System.out.println("Cerrando la conexión con el cliente");
            sc.close();
            conexionSocket.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
