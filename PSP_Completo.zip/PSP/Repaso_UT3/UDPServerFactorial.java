import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServerFactorial {
    public static void main(String[] args){
        int puerto = 54321;

        try {
            DatagramSocket servidor = new DatagramSocket(puerto);

            InetAddress client1 = null;
            InetAddress client2 = null;

            byte[] buffer = new byte[1024];

            int contador = 0;
            int puertoCliente1 = 0, puertoCliente2 = 0;

            while (contador < 2){
                DatagramPacket paqueteCliente = new DatagramPacket(buffer, buffer.length);
                servidor.receive(paqueteCliente);
                String tipo = new String(paqueteCliente.getData());
                String tipofinal = tipo.trim();
                if(tipofinal.equals("cliente1")&& client1 == null){
                    client1 = paqueteCliente.getAddress();
                    puertoCliente1 = paqueteCliente.getPort();
                    contador++;
                    System.out.println("Se ha conectado el cliente 1");
                }else if(tipofinal.equals("cliente2") && client2 == null){
                    client2 = paqueteCliente.getAddress();
                    puertoCliente2 = paqueteCliente.getPort();
                    contador++;
                    System.out.println("Se ha conectado el cliente 2");
                }else{
                    System.out.println("El cliente ya se ha conectado o no es valido");
                }
            }

            String avisar = "La conexión se ha realizado correctamente";
            byte[] envio = avisar.getBytes();
            DatagramPacket enviar = new DatagramPacket(envio, envio.length, client1, puertoCliente1);
            servidor.send(enviar);

            byte[] envio2 = avisar.getBytes();
            DatagramPacket enviar2 = new DatagramPacket(envio2, envio2.length, client2, puertoCliente2);
            servidor.send(enviar2);

            buffer = new byte[1024];

            //recogida de datos
            DatagramPacket recibir = new DatagramPacket(buffer, buffer.length);
            servidor.receive(recibir);

            String recibido = new String(recibir.getData()).trim();
            System.out.println(recibido);

            envio2 = recibido.trim().getBytes();

            //enviar al otro cliente
            DatagramPacket enviarNumero = new DatagramPacket(envio2, envio2.length, client2, puertoCliente2);
            System.out.println("Enviando numero al cliente 2");
            servidor.send(enviarNumero);

            //recibir al primer cliente
            buffer = new byte[1024];
            DatagramPacket recibir2 = new DatagramPacket(buffer, buffer.length);
            servidor.receive(recibir2);
            String recibido2 = new String(recibir.getData()).trim();
            System.out.println(recibido2);
            envio = recibido2.trim().getBytes();

            //enviar al primer cliente
            DatagramPacket enviarNumeroFinal = new DatagramPacket(envio, envio.length, client1, puertoCliente1);
            System.out.println("Enviando numero al cliente 1");
            servidor.send(enviarNumeroFinal);

            System.out.println("El servidor cierra su sesion");

            servidor.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
