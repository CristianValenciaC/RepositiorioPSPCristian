import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServerJuego{
    public static void main(String[] args){
        try {
            //Creación de los socket
            int puerto = 54321;
            ServerSocket servidor = new ServerSocket(puerto);
            System.out.println("Servidor conectado al puerto: " + puerto);
            System.out.println("----------------------------------------");

            //Creación de los DataInputStream y DataOutputStream
            InputStream[] entradaclientes = new InputStream[4];
            DataInputStream[] flujosEntrada = new DataInputStream[4];
            OutputStream[] salidaClientes = new OutputStream[4];
            DataOutputStream[] flujosSalida = new DataOutputStream[4];

            //Obtencion del pid del servidor

            int pidAdivinar = (int) ProcessHandle.current().pid();

            //Conexión de clientes
            Socket[] clientes = new Socket[4];
            System.out.println("Esperando usuarios....");
            for (int i = 0; i < clientes.length; i++) {
                clientes[i]= servidor.accept();
                entradaclientes[i] = clientes[i].getInputStream();
                flujosEntrada[i] = new DataInputStream(entradaclientes[i]);
                salidaClientes[i] = clientes[i].getOutputStream();
                flujosSalida[i] = new DataOutputStream(salidaClientes[i]);
            }


        
            servidor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}