import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServerFactorial {
    public static void main(String[] args){
        int puerto = 54321;

        try {
            ServerSocket servidor = new ServerSocket(puerto);
            Socket clientePos = null;
            Socket client1 = null;
            Socket client2 = null;

            int contador = 0;

            while (contador < 2){
                clientePos = servidor.accept();
                DataInputStream tipoCliente = new DataInputStream(clientePos.getInputStream());
                String tipo = tipoCliente.readUTF();
                if(tipo.equals("cliente1")&& client1 == null){
                    client1 = clientePos;
                    contador++;
                    System.out.println("Se ha conectado el cliente 1");
                }else if(tipo.equals("cliente2") && client2 == null){
                    client2 = clientePos;
                    contador++;
                    System.out.println("Se ha conectado el cliente 2");
                }else{
                    System.out.println("El cliente ya se ha conectado o no es valido");
                }
            }

            DataOutputStream flujoSalidaCliente2 = new DataOutputStream(client2.getOutputStream());
            DataOutputStream flujoSalidaCliente1 = new DataOutputStream(client1.getOutputStream());
            flujoSalidaCliente1.writeUTF("Conexión realizada correctamente");
            flujoSalidaCliente2.writeUTF("Conexión realizada correctamente");
            //recogida de datos
            DataInputStream flujoCliente1 = new DataInputStream(client1.getInputStream());
            int numero = flujoCliente1.readInt();

            //enviar al otro cliente
            
            System.out.println("Enviando numero " + numero + " del cliente 1 al cliente 2");
            flujoSalidaCliente2.writeInt(numero);

            DataInputStream flujoCliente2 = new DataInputStream(client2.getInputStream());
            int numeroFactorial = flujoCliente2.readInt();
            System.out.println("El servidor recibe el factorual");

            //enviar al primer cliente
            System.out.println("El servidor envia el número recibido");
            flujoSalidaCliente1.writeInt(numeroFactorial);

            System.out.println("El servidor cierra su sesion");

            client1.close();
            client2.close();
            servidor.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
