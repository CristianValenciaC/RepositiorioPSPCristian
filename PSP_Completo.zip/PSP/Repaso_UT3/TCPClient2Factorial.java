import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class TCPClient2Factorial {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 54321;

        try {
            Socket conexionSocket = new Socket(host, puerto);
            System.out.println("Mandando mensaje de conexión");
            String cliente = "cliente2";

            DataOutputStream mensaje = new DataOutputStream(conexionSocket.getOutputStream());
            mensaje.writeUTF(cliente);

            DataInputStream recibo = new DataInputStream(conexionSocket.getInputStream());
            String contenido = recibo.readUTF();

            System.out.println(contenido);
            
            System.out.println("Recibiendo numero del servidor");
            int numero = recibo.readInt();

            int numeroFinal = calcularFactorial(numero);

            System.out.println("Enviando numero al servidor");
            mensaje.writeInt(numeroFinal);

            System.out.println("Cerrando la conexión con el cliente");
            conexionSocket.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static int calcularFactorial(int num) {
		if (num==0)
		    return 1;
		  else
		    return num * calcularFactorial(num-1);
	}
}
