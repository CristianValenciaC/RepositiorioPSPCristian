import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPClient2Factorial {
    public static void main(String[] args) {
        int puerto = 54321;

        try {
            DatagramSocket conexionCliente = new DatagramSocket();

            byte[] buffer = new byte[1024];

            InetAddress servidor = InetAddress.getLocalHost();

            System.out.println("Mandando mensaje de conexión");
            String cliente = "cliente2";

            byte[] mensajeConfirmacion = new byte[1024];
            mensajeConfirmacion = cliente.getBytes();

            DatagramPacket paqueteConfirmacion = new DatagramPacket(mensajeConfirmacion, mensajeConfirmacion.length, servidor, puerto);
            conexionCliente.send(paqueteConfirmacion);

            DatagramPacket reciboConfirmacion = new DatagramPacket(buffer, buffer.length);
            conexionCliente.receive(reciboConfirmacion);

            String contenido = new String(reciboConfirmacion.getData());

            System.out.println(contenido);
            
            System.out.println("Recibiendo numero del servidor");
            buffer = new byte[1024];
            DatagramPacket recibo = new DatagramPacket(buffer, buffer.length);
            conexionCliente.receive(recibo);

            String recibido = new String(recibo.getData()).trim();
            System.out.println(recibido);
            int numero = Integer.parseInt(recibido);

            int numeroFinal = calcularFactorial(numero);

            System.out.println("Enviando numero al servidor");
            String envioNumeroFinal = String.valueOf(numeroFinal);
            byte[] bytenumeroFinal = envioNumeroFinal.trim().getBytes();

            System.out.println("Cerrando la conexión con el cliente");
            DatagramPacket envioNumFinal = new DatagramPacket(bytenumeroFinal, bytenumeroFinal.length, servidor, puerto);
            conexionCliente.send(envioNumFinal);

            conexionCliente.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static int calcularFactorial(int num) {
		if (num==0)
		    return 1;
		  else
		    return num * calcularFactorial(num-1);
	}
}
