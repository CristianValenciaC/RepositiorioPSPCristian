package ut3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class ClientSocketMandarNum {
	public static void main(String[] args) throws Exception {
		String Host = "localhost";
		int Puerto = 6666;//puerto remoto	
		
		System.out.println("PROGRAMA CLIENTE INICIADO....");
		Socket Cliente = new Socket(Host, Puerto);
	
		// Creación flujo de salida hacia el servidor
		//Output para mandar info
		DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
		
		//Números que manda al servidor para que los sume
		int [] numeros = {2,3,5,1,4};
		
		for(int i=0;i<numeros.length;i++) {
			flujoSalida.writeInt(numeros[i]);
		}
	
		// Creación flujo de entrada desde el servidor
		//Input para leer info
		DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());
	
		// 
		System.out.println("Recibiendo del SERVIDOR la suma: \n\t" + flujoEntrada.readInt());
	
		// CERRAR STREAMS Y SOCKETS	
		flujoEntrada.close();	
		flujoSalida.close();	
		Cliente.close();	
	}// main
}
