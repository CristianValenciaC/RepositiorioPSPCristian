package ej3_socket;

import java.io.*;
import java.net.*;

public class TCPServerSocket2 {
    public static void main(String[] args) throws IOException {
        int numeroPuerto = 6666;// Puerto
        ServerSocket servidor = new ServerSocket(numeroPuerto);
        Socket clienteConectado = null;
        System.out.println("Esperando al cliente.....");
        clienteConectado = servidor.accept();//conectando cliente misma ip
    
        // Creación flujo de entrada del cliente
        InputStream entrada = null;
        entrada = clienteConectado.getInputStream();
        DataInputStream flujoEntrada = new DataInputStream(entrada);
        
        //procesamiento de información
        int suma = 0;
        for(int i = 0; i < 4; i++){
            suma += flujoEntrada.readInt();
        }

        //Recibiendo datos del cliente ...
        System.out.println("Recibiendo del CLIENTE: \n\tHa recibido los numeros correctamente");
    
        // Creación flujo de entrada del cliente
        OutputStream salida = null;
        salida = clienteConectado.getOutputStream();
        DataOutputStream flujoSalida = new DataOutputStream(salida);
    
        //Enviando datos al cliente
        flujoSalida.writeUTF("Saludos al cliente del servidor:\n\tLa suma de los numeros enivados es: " + suma);
    
        // Cierre streams y sockets
        entrada.close();
        flujoEntrada.close();
    
        salida.close();
        flujoSalida.close();
        
        clienteConectado.close();
        servidor.close();
      }// main
}
