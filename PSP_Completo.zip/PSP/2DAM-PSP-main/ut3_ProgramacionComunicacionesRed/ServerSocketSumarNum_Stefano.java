package ut3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSocketSumarNum {
	public static void main(String[] arg) throws IOException {
		int numeroPuerto = 6666;// Puerto
		ServerSocket servidor = new ServerSocket(numeroPuerto);
		Socket clienteConectado = null;
		System.out.println("Esperando al cliente.....");
		clienteConectado = servidor.accept();
	
		// Creación flujo de entrada del cliente
		//Input para leer info
		InputStream entrada = null;
		entrada = clienteConectado.getInputStream();
		DataInputStream flujoEntrada = new DataInputStream(entrada);
		
		int[] numeros = new int[5];
		int suma=0;
		
		//Recibiendo datos del cliente ...
		for(int i=0;i<numeros.length;i++) {
			numeros[i]=flujoEntrada.readInt();
			suma=suma+numeros[i];
			System.out.println("Recibiendo del CLIENTE: \n\t" + numeros[i]);
		}
	
		// Creación flujo de salida
		//Output para mandar info
		OutputStream salida = null;
		salida = clienteConectado.getOutputStream();
		DataOutputStream flujoSalida = new DataOutputStream(salida);
	
		//Enviando datos al cliente
		flujoSalida.writeInt(suma);
	
		// Cierre streams y sockets
		entrada.close();
		flujoEntrada.close();
	
		salida.close();
		flujoSalida.close();
		
		clienteConectado.close();
		servidor.close();
	}// main
}
