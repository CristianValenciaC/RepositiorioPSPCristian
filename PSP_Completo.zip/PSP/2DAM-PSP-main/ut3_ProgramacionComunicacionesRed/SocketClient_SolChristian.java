package ej3_socket;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TCPClientSocket2 {
    public static void main(String[] args) throws Exception {
        String Host = "localhost";
        int Puerto = 6666;//puerto remoto	
        
        System.out.println("PROGRAMA CLIENTE INICIADO....");
        Socket Cliente = new Socket(Host, Puerto);//creación conexión cliente
    
        // Creación flujo de salida hacia el servidor
        DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
        Scanner sc = new Scanner(System.in);
        for(int i = 1; i <= 4; i++){
            System.out.println("Introduce el numero: "+ i);
            int num = sc.nextInt();
            flujoSalida.writeInt(num);
        }
        
        // Creación flujo de entrada desde el servidor
        DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());
    
        // 
        System.out.println("Recibiendo del SERVIDOR: \n\t" + flujoEntrada.readUTF());//recibiendo contenido del servidor
    
        // CERRAR STREAMS Y SOCKETS	
        sc.close();
        flujoEntrada.close();	
        flujoSalida.close();	
        Cliente.close();	
      }// main
}
