import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class Estudianteclient {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        //Creamos los elementos para el envio y recibimiento de archivos
        byte[] envio = new byte[1024];
        byte[] buffer = new byte[1024];

        //Creamos un socket para el datagrama y obtenemos el localhost y el puerto del servidor
        DatagramSocket conexionCliente = new DatagramSocket();
        InetAddress ipServidor = InetAddress.getLocalHost();
        int puerto = 54321;

        //introducimos un valor para enviar al servidor
        System.out.print("¿Numero matrícula alumno?: ");
        String mensaje = sc.next();

        //envio de paquete al servidor con el numero de matricula
        envio = mensaje.getBytes();
        DatagramPacket envioNumMatricula = new DatagramPacket(envio, envio.length, ipServidor,puerto);
        conexionCliente.send(envioNumMatricula);

        //recibimiento del paquete servidor y obtención de la información
        DatagramPacket reciboEstudiante = new DatagramPacket(buffer, buffer.length);
        conexionCliente.receive(reciboEstudiante);
        ByteArrayInputStream baestudiante = new ByteArrayInputStream(reciboEstudiante.getData());
        ObjectInputStream oestudiante = new ObjectInputStream(baestudiante);
        
        estudiante estudianteEnviado = (estudiante) oestudiante.readObject();

        //comprueba si el estudiante recibido es nulo o no
        if(estudianteEnviado == null){
            System.out.println("Atención! Matricula " + mensaje + " no existe");
        }else{
            System.out.println("Nombre Alumno: " + estudianteEnviado.getNombre());
            System.out.println("Media calificaciones: " + estudianteEnviado.mediaEstudiante());
        }

        //cierra la conexión con el servidor
        sc.close();
        conexionCliente.close();
    }
}
