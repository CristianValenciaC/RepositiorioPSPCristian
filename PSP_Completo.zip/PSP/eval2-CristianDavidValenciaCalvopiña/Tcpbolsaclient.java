import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Tcpbolsaclient{

    public static void main(String[] args) throws UnknownHostException, IOException {
        //crea la conexión para el socket y el escaner para la informacion
        String host = "localhost";
        int puerto = 55555;
        Scanner sc = new Scanner(System.in);

        System.out.println("Cliente Iniciado...");

        //conexión de socket y envio de mensaje
        Socket conexionCliente = new Socket(host, puerto);
        System.out.println("Introduzca la empresa");
        String nombreEmpresa = sc.next();
        DataOutputStream dos = new DataOutputStream(conexionCliente.getOutputStream());
        dos.writeUTF(nombreEmpresa);

        //recibe el mensaje mediante un array de String que va a recoger su valor y va a comprobar que el string recogido no sea el de por defecto del servidor
        DataInputStream dis = new DataInputStream(conexionCliente.getInputStream());
        boolean vacio = false;
        String[] resultado = new String[4];
        for(int i = 0; i < resultado.length; i++){
            resultado[i] = dis.readUTF();
            if(resultado[i].equals("no hay")){
                vacio = true;
            }
        }

        //comprueba que no haya habido informacion por defecto del servidor
        if (vacio) {
            System.out.println("La empresa buscada no existe");
        } else {
            System.out.println("Datos cotizacion empresa " + resultado[0]);
            System.out.println("Cotización:"+resultado[1]);
            System.out.println("Maximo:"+resultado[2]);
            System.out.println("Minimo:"+resultado[3]);
        }
        //finaliza el cliente
        System.out.println("Cliente finalizado");
        sc.close();
        conexionCliente.close();
    }
    
}