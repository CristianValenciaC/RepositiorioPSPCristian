import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;

// Esqueleto de la clase estudiante
// Deberá ser implementado completamente por el alumno
class estudiante implements Serializable  {
    private String nombre, nummatricula; //nombre del alumno y numero matricula
    private double nota_psp,nota_pmm,nota_sge,nota_di,nota_eie; //notas obtenidas por alumno: nota psp, nota pmm, nota sge, nota di, nota eie

    public estudiante(String nombre, String nummatricula, double nota_psp, double nota_pmm, double nota_sge, double nota_di, double nota_eie){
        this.nombre = nombre;
        this.nummatricula = nummatricula;
        this.nota_psp = nota_psp;
        this.nota_pmm = nota_pmm;
        this.nota_sge = nota_sge;
        this.nota_di = nota_di;
        this.nota_eie = nota_eie;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNummatricula() {
        return nummatricula;
    }
    public void setNummatricula(String nummatricula) {
        this.nummatricula = nummatricula;
    }

    public double getNota_psp() {
        return nota_psp;
    }

    public void setNota_psp(double nota_psp) {
        this.nota_psp = nota_psp;
    }

    public double getNota_pmm() {
        return nota_pmm;
    }

    public void setNota_pmm(double nota_pmm) {
        this.nota_pmm = nota_pmm;
    }

    public double getNota_sge() {
        return nota_sge;
    }

    public void setNota_sge(double nota_sge) {
        this.nota_sge = nota_sge;
    }

    public double getNota_di() {
        return nota_di;
    }

    public void setNota_di(double nota_di) {
        this.nota_di = nota_di;
    }

    public double getNota_eie() {
        return nota_eie;
    }

    public void setNota_eie(double nota_eie) {
        this.nota_eie = nota_eie;
    }
    //calculamos la nota media de estudiantes
    public double mediaEstudiante(){
        double media = 0;

        media = (nota_di + nota_eie + nota_pmm + nota_psp + nota_sge)/5;

        return media;
    }
}

//Clase principal
public class Estudianteserver {
    public static void main(String[] args) throws Exception {
		
		//Definición de ArrayList con los estudiantes y sus calificaciones
        ArrayList <estudiante>  listaestudiantes = new ArrayList<>();
        listaestudiantes.add(new estudiante("Fernando Alonso","2023001",7.5,4.0,8.0,0.0,5.5));
        listaestudiantes.add(new estudiante("Lewis Hamilton","2023002",5.0,4.3,2.8,10.0,5.2));
        listaestudiantes.add(new estudiante("Carlos Sainz","2023003",8.5,9.3,1.5,10.0,2.5));
        listaestudiantes.add(new estudiante("Sebastian Vettel","2023004",5.0,9.0,10.0,10.0,7.3));       
       
       //Creación de conexion para el servidor
       int puerto = 54321;
       DatagramSocket servidor = new DatagramSocket(puerto);

       System.out.println("Servidor preparado ...");

       while(true){
        //creación de buffers para cada consulta que se realiza
        byte[] buffer = new byte[1024];
        byte[] mensajeParaCliente = new byte[1024];

        //creacion de paquete de recibir el numero de matricula y obtención mensaje del string
        DatagramPacket paqueteCliente = new DatagramPacket(buffer, buffer.length);
        servidor.receive(paqueteCliente);
        String mensaje = new String(paqueteCliente.getData()).trim();

        //creamos un estudiante nulo, para el envio
        estudiante estudianteParaCliente = null;

        //comprobación de que exista el numero de matricula para obtener el objeto requerido
        for(estudiante busquEstudiante : listaestudiantes){
            if(mensaje.equals(busquEstudiante.getNummatricula())){
                estudianteParaCliente = busquEstudiante;
            }
        }

        //envia el objeto del alumno al cliente
        ByteArrayOutputStream baoestudiante = new ByteArrayOutputStream();
        ObjectOutputStream ooestudiante = new ObjectOutputStream(baoestudiante);
        ooestudiante.writeObject(estudianteParaCliente);
        mensajeParaCliente = baoestudiante.toByteArray();
        DatagramPacket mensajeCliente = new DatagramPacket(mensajeParaCliente,mensajeParaCliente.length, paqueteCliente.getAddress(), paqueteCliente.getPort());
        servidor.send(mensajeCliente);

       }
    } // main()
} // class
