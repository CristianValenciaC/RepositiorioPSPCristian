import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Tcpbolsaserver{

    public static void main(String[] args) throws IOException {
        //creamos un puerto para crear un socket servidor
        int puerto = 55555;
        ServerSocket servidor = new ServerSocket(puerto);

        //creamos un cliente y espera a que el cliente se conecte
        Socket cliente = null;
        System.out.println("Esperado al cliente.....");
        cliente = servidor.accept();

        //Espera el mensaje que va a recibir del cliente y si lo envia en minuscula lo convierte a mayuscula
        DataInputStream recibir = new DataInputStream(cliente.getInputStream());
        String nombreEmpresa = recibir.readUTF().toUpperCase();
        System.out.println("Empresa a buscar: \n" + nombreEmpresa);

        //lee el archivo para buscar la información de la empresa que solicita el cliente
        File archivo = new File("ibex35.txt");
        FileReader lectura = new FileReader(archivo);
        BufferedReader lecturaLinea = new BufferedReader(lectura);
        
        //creamos un array de string para almacenar una información diferente del archivo e inicializamos sus valores
        String[] valores = new String[4];

        for(int i = 0; i< valores.length; i++){
            valores[i] = "no hay";
        }

        //lectura del archivo

        String conjuntoDatos = lecturaLinea.readLine();

        while(conjuntoDatos!=null){
            String lString = conjuntoDatos;
            //Creo un array de string a partir de un separador que es la almohadilla o hastag
            String[] apartados = lString.split("\\#");
            if(apartados[0].equals(nombreEmpresa)){
                valores[0] = apartados[0];
                valores[1] = apartados[1];
                valores[2] = apartados[2];
                valores[3] = apartados[3];
            }
            conjuntoDatos = lecturaLinea.readLine();
        }

        //cerramos la lectura del archivo
        lecturaLinea.close();

        //envio de información recorriendo el array de string creado anteriormente
        DataOutputStream envioInformacion = new DataOutputStream(cliente.getOutputStream());
        for(int i = 0; i< valores.length; i++){
            envioInformacion.writeUTF(valores[i]);
        }

        //finaliza el servidor
        System.out.println("Servidor Finalizado");
        cliente.close();
        servidor.close();
    }
}