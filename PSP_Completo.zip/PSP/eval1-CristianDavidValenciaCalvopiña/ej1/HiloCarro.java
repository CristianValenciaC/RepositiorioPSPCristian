public class HiloCarro implements Runnable {

    private Carro importeCarro;//realiza el calculo del carro
    private String nombreAlumno;
    private int carrito[];
    
    public HiloCarro(String nombreAlumno, int carrito[]){
        importeCarro = new Carro();
        this.nombreAlumno = nombreAlumno;
        this.carrito = carrito;
    }
    
    @Override
    public void run() {
        // TODO Auto-generated method stub
        importeCarro.calcularImporteCarro(nombreAlumno,carrito);
    }
    
}
