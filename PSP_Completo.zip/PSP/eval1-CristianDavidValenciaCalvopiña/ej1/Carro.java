public class Carro{

    private int importe = 0;

    public void calcularImporteCarro(String nombre, int carro[]){
        System.out.println("Carro del " +nombre + " procesando...");
        for(int i = 0; i<carro.length; i++){//calcula el importe total del carrito
            importe+=carro[i];
        }

        System.out.println("Importe total carro "+ nombre +" = " + importe + "€");
        System.out.println("Carro del "+nombre+ " terminado.");

        try {
            Thread.sleep(10);//al finalizar el programa, duerme el hilo 10 milisegundos
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}