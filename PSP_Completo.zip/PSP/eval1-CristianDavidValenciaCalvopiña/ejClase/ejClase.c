#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

//Proceso padre pide n numeros hasta que introduzcamos 0
//Pide la suma de numeros suma(pipe2)
//Pide la cantidad de numeros impares (pipe 3)

void main()
{
    int pipe1[2];
    int pipe2[2];
    int pipe3[2];

    pipe(pipe1);
    pipe(pipe2);
    pipe(pipe3);

    int contador = 0;

    pid_t hijo;

    hijo = fork();
    
    if (hijo == 0)
    {
        /* code */
        close(pipe1[1]);
        close(pipe2[0]);
        close(pipe3[0]);

        while (contador != 0)
        {
            /* code */
        }
        
    }
    else
    {
        /* code */
        close(pipe1[0]);
        close(pipe2[1]);
        close(pipe3[1]);
    }
    
}