#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
void main()
{
  int filepipe1[2],filepipe2[2],filepipe3[2];
  int contador;
  pid_t pid;
  char buffer[10];
  //Creamos los pipes
  pipe(filepipe1);
  pipe(filepipe2);
  pipe(filepipe3);
  pid=fork();
  if (pid==0)
  { // Es el proceso hijo
    //Cierre descriptores
    close(filepipe1[0]);
    close(filepipe2[1]);
    close(filepipe3[1]);
   //Petición de datos
    for (int i = 0; i < 5; i++)
    {
     printf("Introduce un número:");
     scanf("%d", &contador);
     printf("Número: %d\n",contador);
     //Almacenamos en array tipo char la variable int contador
     sprintf(buffer,"%d",contador);
     write(filepipe1[1],buffer,sizeof(buffer));
    }
  }
  else
  { // Es el proceso padre
    //Cierre descriptores
    close(filepipe1[1]);
    close(filepipe2[0]);
    close(filepipe3[0]);
    //Lectura de los numeros que llegan por pipe1
    int contador = 0;
    while (contador < 5 ){
        contador++;
        read(filepipe1[0], &buffer, sizeof(buffer));
        printf("Numero leído %s: \n", buffer);
    }
    wait(NULL);
  }
}







