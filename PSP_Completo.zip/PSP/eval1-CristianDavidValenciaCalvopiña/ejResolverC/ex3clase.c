#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

void main()
{
  int filepipe1[2],filepipe2[2],filepipe3[2];
  pid_t pid;

    int contador;
    int contadorMultiplo5 = 0;
    int suma = 0;

  //Creamos los pipes
  pipe(filepipe1);
  pipe(filepipe2);
  pipe(filepipe3);
  pid=fork();
  if (pid==0)
  { // Es el proceso hijo
    //Cierre descriptores
    close(filepipe1[0]);
    close(filepipe2[1]);
    close(filepipe3[1]);
   //Petición de datos
    for (int i = 0; i < 5; i++)
    {
     printf("Introduce un numero");
     scanf("%d", &contador);
     //printf("Los numeros introducidos son %d\n",contador);
     //Almacenamos en array tipo char la variable int contador
     //sprintf(buffer, "&d", contador);
     write(filepipe1[1], &contador, sizeof(contador));
    }
    read(filepipe2[0], &contadorMultiplo5, sizeof(contadorMultiplo5));
    printf("De los numeros enviados, %d, son multiplo de 5\n", contadorMultiplo5);
    read(filepipe3[0], &suma, sizeof(suma));
    printf("La suma de los multiplos de 5 son: %d\n", suma);

  }
  else
  { // Es el proceso padre
    //Cierre descriptores
    close(filepipe1[1]);
    close(filepipe2[0]);
    close(filepipe3[0]);
    
    while(read(filepipe1[0], &contador, sizeof(contador))!=0)
    {
        printf("Numero leido : %d\n", contador);
        if(contador%5==0)
        {
            contadorMultiplo5++;
            suma += contador;
        }
    }
    write(filepipe2[1], &contadorMultiplo5, sizeof(contadorMultiplo5));
    write(filepipe3[1], &suma, sizeof(suma));

    wait(NULL);
  }
}