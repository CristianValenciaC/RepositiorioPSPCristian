#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <string.h>



void main()
{
    //crear descriptores de lectura y escritura
    int fd1[2];
    int fd2[2];
    int fd3[2];

    //pid para el hijo
    pid_t hijo;

    //crear buffers

    //creamos los pipes --> pipe: da los descriptores de lectura
    pipe(fd1);
    pipe(fd2);
    pipe(fd3);

    hijo = fork();//Crear proceso hijo

    if (hijo == 0)
    {
        /*Proceso hijo*/
        //cerrar descriptores para el envio y lectura del pipe
        close(fd1[0]);
        close(fd2[1]);
        close(fd3[1]);

        int numeros[4];
        for(int i = 0; i < 5; i++)
        {
            scanf("%d", &numeros[i]);
            printf("%d", numeros[i]);
        }
    }
    else
    {
        /*Proceso padre*/
        //cerrar descriptores para el envio y lectura del pipe
        close(fd1[1]);
        close(fd2[0]);
        close(fd3[0]);
        wait(NULL);
    }
    

}