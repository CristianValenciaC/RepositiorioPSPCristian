package ej2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Ej2SocketClienteTCP {

	public static void main(String[] args) {
		//Declaracion de conectores
		String host = "localhost";
		int puerto = 62000;
		
		//Conexion
		System.out.println("Programa cliente iniciado....");
		try {
			Socket Cliente = new Socket(host, puerto);
			System.out.println("####################################");
			System.out.println("El cliente se ha conectado correctamente, comenzando ejecucion del programa\n");
	
			//Declaracion de variables
			int[] arrayNum = new int[10];
			for(int i = 0; i < arrayNum.length; i++) {
				arrayNum[i]=(int) (Math.random()*1000);
				System.out.println("Numeros del array: " + arrayNum[i]);
			}
			int resultadoSuma, numMayor, numMenor;
			
			//Creando flujo de salida
			DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
			for(int i = 0; i < arrayNum.length; i++) {
				flujoSalida.writeInt(arrayNum[i]);
			}
			
			//Recibiendo numero
			DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());
			resultadoSuma = flujoEntrada.readInt();
			numMayor = flujoEntrada.readInt();
			numMenor = flujoEntrada.readInt();
			
			System.out.println("Del array enviado, la suma de todos los numeros es de " + resultadoSuma);
			System.out.println("Del array enviado, el numero mayor es " + numMayor);
			System.out.println("Del array enviado, el numero menor es " + numMenor);
			
			//Cierre conexion
			System.out.println("El cliente cierra la conexion");
			Cliente.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha encontrado la conexion con el servidor");
			e.printStackTrace();
		}
	}
}
