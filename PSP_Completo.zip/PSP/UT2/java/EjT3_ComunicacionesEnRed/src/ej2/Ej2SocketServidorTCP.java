package ej2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Ej2SocketServidorTCP {

	public static void main(String[] args) throws IOException {
		//Creando conexion del servidor
		int puerto1Cliente = 62000;	
		ServerSocket servidor1 = new ServerSocket(puerto1Cliente);
		
		//Creando conectores Clientes
		Socket cliente1Conectado = null;
		System.out.println("Esperando al cliente 1 y 2.....");
		cliente1Conectado = servidor1.accept();
		
		//Creando variables
		int resultadoSuma = 0, numMayor = 0, numMenor = 0;
		
		//recibiendo mensaje de socketCliente1
		System.out.println("Esperando mensaje de cliente 1");
		DataInputStream flujoEntrada = new  DataInputStream(cliente1Conectado.getInputStream());
		for(int i = 0; i < 10; i++) {
			int numEnviado = flujoEntrada.readInt();
			resultadoSuma += numEnviado;
			if((int)numEnviado>=numMayor) {
				numMayor = numEnviado;
				if(i == 0) {
					numMenor = numMayor;
				}
			}
			if((int)numEnviado<=numMenor) {
				numMenor = numEnviado;
			}
		}
		
		System.out.println("Recibido correctamente mensaje, realizando el envio a cliente 1");
		
		//
		
		//enviando mensaje a socketCliente1
		DataOutputStream flujoSalida2 = new DataOutputStream(cliente1Conectado.getOutputStream());
		flujoSalida2.writeInt(resultadoSuma);
		flujoSalida2.writeInt(numMayor);
		flujoSalida2.writeInt(numMenor);
		
		//Cerrando servidor
		System.out.println("El servidor se cierra");
		servidor1.close();
		
	}
}
