package ej1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Ej1SocketServidorTCP {

	public static void main(String[] args) throws IOException {
		//Creando conexion del servidor
		int puerto1Cliente = 62750;	
		int puerto2Cliente = 62751;
		ServerSocket servidor1 = new ServerSocket(puerto1Cliente);
		ServerSocket servidor2 = new ServerSocket(puerto2Cliente);
		
		//Creando conectores Clientes
		Socket cliente1Conectado = null;
		Socket cliente2Conectado = null;
		System.out.println("Esperando al cliente 1 y 2.....");
		cliente1Conectado = servidor1.accept();
		cliente2Conectado = servidor2.accept();
		
		//recibiendo mensaje de socketCliente1
		System.out.println("Esperando mensaje de cliente 1");
		DataInputStream flujoEntrada = new  DataInputStream(cliente1Conectado.getInputStream());
		int num = flujoEntrada.readInt();
		
		System.out.println("Recibido correctamente mensaje, realizando el envio a cliente2");
		//enviando mensaje a socketCliente2
		DataOutputStream flujoSalida = new DataOutputStream(cliente2Conectado.getOutputStream());
		flujoSalida.writeInt(num);
		
		//recibiendo mensaje de socketCliente2
		System.out.println("Esperando mensaje de cliente 2");
		DataInputStream flujoEntrada2 = new  DataInputStream(cliente2Conectado.getInputStream());
		int numFinal = flujoEntrada2.readInt();
		
		System.out.println("Recibido correctamente mensaje, realizando el envio a cliente 1");
		//enviando mensaje a socketCliente1
		DataOutputStream flujoSalida2 = new DataOutputStream(cliente1Conectado.getOutputStream());
		flujoSalida2.writeInt(numFinal);
		
		//Cerrando servidor
		System.out.println("El servidor se cierra");
		servidor1.close();
		servidor2.close();
		
	}
}
