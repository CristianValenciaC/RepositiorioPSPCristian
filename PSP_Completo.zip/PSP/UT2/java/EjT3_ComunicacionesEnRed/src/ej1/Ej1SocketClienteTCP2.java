package ej1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Ej1SocketClienteTCP2 {

	public static void main(String[] args) {
		//Declaracion de conectores
		String host = "localhost";
		int puerto = 62751;
		
		//Declaracion de variables
		int num, numFinal;
		
		//Conexion
		System.out.println("Programa cliente iniciado....");
		try {
			Socket Cliente = new Socket(host, puerto);
			System.out.println("####################################");
			System.out.println("El cliente se ha conectado correctamente\n");
			
			System.out.println("El cliente espera a recibir un numero del servidor");
			
			//Recibiendo el numero desde el servidor
			DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());
			num = flujoEntrada.readInt();
			
			//Calculando el numero factorial mediante un metodo recursivo			
			numFinal = calcularFactorial(num);
			
			//Creando flujo de salida
			DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
			flujoSalida.writeInt(numFinal);
			
			//Cierre conexion
			System.out.println("El cliente cierra la conexion");
			Cliente.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha encontrado la conexion con el servidor");
			e.printStackTrace();
		}
	}
	
	public static int calcularFactorial(int num) {
		if (num==0)
		    return 1;
		  else
		    return num * calcularFactorial(num-1);
	}
}
