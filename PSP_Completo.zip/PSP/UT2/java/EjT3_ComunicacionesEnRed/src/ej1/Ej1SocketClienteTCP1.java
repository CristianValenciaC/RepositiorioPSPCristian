package ej1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.*;

public class Ej1SocketClienteTCP1 {

	private static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		//Declaracion de conectores
		String host = "localhost";
		int puerto = 62750;
		
		//Declaracion de variables
		int num, numFinal;
		
		//Conexion
		System.out.println("Programa cliente iniciado....");
		try {
			Socket Cliente = new Socket(host, puerto);
			System.out.println("####################################");
			System.out.println("El cliente se ha conectado correctamente, comenzando ejecucion del programa\n");
			
			//Creando la información para el envio
			System.out.println("\nIntroduzca un numero");
			num = sc.nextInt();
			
			//Creando flujo de salida
			DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());
			flujoSalida.writeInt(num);
			
			//Recibiendo numero
			DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());
			numFinal = flujoEntrada.readInt();
			System.out.println("El factorial de " + num + " es " + numFinal);
			
			//Cierre conexion
			System.out.println("El cliente cierra la conexion");
			Cliente.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha encontrado la conexion con el servidor");
			e.printStackTrace();
		}
	}
}
