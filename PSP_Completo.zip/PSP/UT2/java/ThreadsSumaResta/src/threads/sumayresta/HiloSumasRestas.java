package threads.sumayresta;

public class HiloSumasRestas implements Runnable {
	 
	private int numero=1000;
	
	private int numveces;
	
	private String operacion;

	 //Constructor de la clase
	 public HiloSumasRestas(int numveces, String operacion)
	 {
		 this.numveces = numveces;
		 this.operacion = operacion;
	 }
	 //Incrementará numero el numvece indicado
	 public int incrementar (int numveces)
	 {
		 for(int i = 0; i < numveces; i++) {
			 numero++;
		 }
		 return numero;
	 }
	 //Decrementará numero el numvece indicado
	 public int decrementar (int numveces)
	 {
		 for(int i = 0; i < numveces; i++) {
			 numero--;
		 }
		 return numero;
	 }
	 public void run() {
		 if(operacion.equals("+")) {
			 System.out.println("ID: " + Thread.currentThread().getId() + "numero: " + incrementar(numveces));
		 }else if(operacion.equals("-")) {
			 System.out.println("ID: " + Thread.currentThread().getId() + "numero: " + decrementar(numveces));
		 }else{
			 System.out.println("No se puede realizar el crecimiento o el decrecimiento");
		 }
	 //Si la operación es “+” se invocará al método incrementar
	 //Si la operación es “-” se invocará al método decrementar
	}
}
