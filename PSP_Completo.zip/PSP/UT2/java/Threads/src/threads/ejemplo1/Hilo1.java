package threads.ejemplo1;

public class Hilo1 extends Thread {
	private int x;

    // Constructor de la clase
	Hilo1(int x) {
		this.x = x;
	}

    // metodo run -> funcionalidad del hilo
	public void run() {
		for (int i = 0; i < x; i++)
			System.out.println("Ejecutando dentro del Hilo... " + "ID Hilo: " +getId()+ " " + i);
	}

	public static void main(String[] args) {
		Hilo1 p = new Hilo1(10); //Crea un hilo
		Hilo1 p2 = new Hilo1(20);
		Hilo1 p3 = new Hilo1(30);
		p.start();//Comienza a funcionar el hilo
		p2.start();
		p3.start();
	}// main

}//PrimerHilo