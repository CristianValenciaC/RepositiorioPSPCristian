package threads.runnable.join.ejemplo1;

public class HiloJoin1REjecutar {
	
	public static void main(String[] args) {
		HiloJoin1R hilo1 = new HiloJoin1R(2000, "+");
		Thread hiloEjecutar1 = new Thread(hilo1);
		
		HiloJoin1R hilo2 = new HiloJoin1R(100, "-");
		Thread hiloEjecutar2 = new Thread(hilo2);
		
		HiloJoin1R hilo3 = new HiloJoin1R(10, "+");
		Thread hiloEjecutar3 = new Thread(hilo3);
		
		HiloJoin1R hilo4 = new HiloJoin1R(500, "-");
		Thread hiloEjecutar4 = new Thread(hilo4);
		
		hiloEjecutar1.start();
		
		try {
			hiloEjecutar1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		hiloEjecutar2.start();
		hiloEjecutar3.start();
		hiloEjecutar4.start();
	}

}
