package threads.runnable.ejemplo1;

public class HiloR1 implements Runnable {

    //método run -> funcionalidad del hilo
	public void run() {
		System.out.println("Hola desde el Hilo: " +  Thread.currentThread().getId());
	}
}
