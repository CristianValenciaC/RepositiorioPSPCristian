package threads.ejercicio2;

public class EjecutarThread2 {

	public static void main(String[] args) {
		Thread2 hilo1 = new Thread2("Hola");
		new Thread(hilo1).start();
		
		Thread2 hilo2 = new Thread2("En medio");
		new Thread(hilo2).start();
		
		Thread2 hilo3 = new Thread2("Adios");
		new Thread(hilo3).start();
	}
	
}
