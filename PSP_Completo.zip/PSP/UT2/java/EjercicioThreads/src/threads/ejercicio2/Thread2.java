package threads.ejercicio2;

public class Thread2 implements Runnable{
	
	private String nombre;
	
	public Thread2(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread.currentThread().setName(nombre);
		for (int i=1; i<=5; i++) 
			System.out.println("Hilo:" + Thread.currentThread().getName() + " Valor del contador i = " + i);
	}

	
	
}
