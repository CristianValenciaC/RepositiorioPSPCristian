package threads.ejercicio3;

public class EjecutarThread3 {

	public static void main(String[] args) {
		Thread3 hilo1 = new Thread3("Incio",20);
		new Thread(hilo1).start();
		Thread3 hilo2 = new Thread3("Medio", 15);
		new Thread(hilo2).start();
		Thread3 hilo3 = new Thread3("Final",30);
		new Thread(hilo3).start();
	}
}
