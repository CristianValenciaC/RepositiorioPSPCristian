package threads.ejercicio3;

public class Thread3 implements Runnable{

	private int x;
	private String nombre;
	
	public Thread3(String nombre, int value) {
		this.x = value;
		this.nombre = nombre;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread.currentThread().setName(nombre);
		for (int i = 0; i < x; i++)
			System.out.println("Ejecutando dentro del Hilo... " + "\nID Hilo: " +Thread.currentThread().getId()+ 
					"\nNombre del hilo: " + Thread.currentThread().getName() + " \nNumero: " +i);
	}

}
