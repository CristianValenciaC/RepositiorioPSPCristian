package threads.ejercicio1;

public class Thread1 implements Runnable{

	private int x;
	
	public Thread1() {
		x = 10;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < x; i++)
			System.out.println("Ejecutando dentro del Hilo... " + "ID Hilo: " +Thread.currentThread().getId()+ " " + i);
	}
	
}
