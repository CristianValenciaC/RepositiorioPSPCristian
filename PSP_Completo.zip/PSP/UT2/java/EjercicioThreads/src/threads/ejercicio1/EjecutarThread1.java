package threads.ejercicio1;

public class EjecutarThread1 {

	
	public static void main(String[] args) {
		Thread1 hilo1 = new Thread1();
		new Thread(hilo1).start();
	}
	
}
