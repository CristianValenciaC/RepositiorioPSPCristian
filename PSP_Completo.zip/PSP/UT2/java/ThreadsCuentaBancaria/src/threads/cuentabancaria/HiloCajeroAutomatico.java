package threads.cuentabancaria;

public class HiloCajeroAutomatico {

	 public static void main(String[] args){

	 // Código de la clase principal
		 CuentaBancaria cuenta1 = new CuentaBancaria();
		 
		 HiloSacarDinero padre = new HiloSacarDinero(cuenta1, "Padre", 200);
		 HiloSacarDinero abuelo = new HiloSacarDinero(cuenta1, "Abuelo", 600);
		 HiloSacarDinero hijo2 = new HiloSacarDinero(cuenta1, "Hijo2", 800);
		 HiloIngresarDinero hijo1 = new HiloIngresarDinero(cuenta1, "Hijo1", 300);
		 HiloSacarDinero madre = new HiloSacarDinero(cuenta1, "Madre", 400);
		 
		 padre.start();
		 abuelo.start();
		 hijo2.start();
		 hijo1.start();
		 madre.start();
	 }
}
