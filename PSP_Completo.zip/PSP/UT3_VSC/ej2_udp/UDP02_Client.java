package ej2_udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import java.util.Scanner;

public class UDP02_Client {
    private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws IOException {

		DatagramSocket clientSocket = new DatagramSocket();// socket cliente

		// DATOS DEL SERVIDOR al que enviar mensaje
		InetAddress IPServidor = InetAddress.getLocalHost();// localhost
		int puerto = 12345; // puerto por el que escucha

		// INTRODUCIR DATOS POR TECLADO
        int posicion = 0;
        boolean salida = false;
        byte[] enviados = new byte[1024];
        while (salida == false){
            System.out.print("Introduce mensaje: ");
            String cadena = sc.nextLine();
            char[] revisarCadena = cadena.toCharArray();
            for(int i = 0; i < revisarCadena.length; i++){
                if(Character.isDigit(revisarCadena[i]) == false){
                    salida = true;
                }
            }
            if(salida == false){
                byte[] contenido;
                contenido = cadena.getBytes();
                enviados[posicion++] = contenido;
            }
        }

		// ENVIANDO DATAGRAMA AL SERVIDOR
		DatagramPacket envio = new DatagramPacket(enviados, enviados.length, IPServidor, puerto);
		clientSocket.send(envio);

		// RECIBIENDO DATAGRAMA DEL SERVIDOR
		byte[] recibidos = new byte[2];
		DatagramPacket recibo = new DatagramPacket(recibidos, recibidos.length);
		System.out.println("Esperando datagrama....");
		clientSocket.receive(recibo);

		// Obtener el numero e caracteres
		byte[] hh = recibo.getData();
		int numero = hh[0];

		System.out.println("Recibo suma " + numero);

		clientSocket.close();// cerrar socket

	}
}
