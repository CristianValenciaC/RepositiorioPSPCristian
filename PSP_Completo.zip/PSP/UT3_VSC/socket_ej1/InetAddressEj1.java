package socket_ej1;

import java.net.*;
import java.util.Scanner;

public class InetAddressEj1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nombreServidor;
        String ipServidor;
        byte[] ipServidorByte;
        int opciones;
        boolean salida = false;

        while(salida == false){
            System.out.println("Introduce una de las siguientes opciones");
            System.out.println("[1]Busqueda por ip"
            +"\n[2]Busqueda por nombre"
            +"\n[3]Salir de la aplicacion");
            opciones = sc.nextInt();
            switch (opciones){
                case 1:
                    System.out.println("========================================================");
                    System.out.println("Info URL: ");
                    try {
                        System.out.println("Introduce una direccion ip");
                        ipServidor = sc.next();
                        ipServidorByte = new byte[ipServidor.length()];


                        InetAddress dir = InetAddress.getByName(ipServidor);
                        System.out.println("\tMetodo getByName():  " + dir);
                        System.out.println("\tMetodo getHostName(): "+ dir.getHostName());
                        System.out.println("\tMetodo getHostAddress(): "+ dir.getHostAddress());
                        System.out.println("\tMetodo toString(): " + dir.toString());
                        System.out.println("\tMetodo getCanonicalHostName(): " + dir.getCanonicalHostName());		
                        
                        // Array de tipo InetAddress con todas las direcciones IP 
                        //asignadas a google.es
                        System.out.println("\tDIRECCIONES IP PARA: " + dir.getHostName());
                        InetAddress[] direcciones = 
                                    InetAddress.getAllByName(dir.getHostName());
                        for (int i = 0; i < direcciones.length; i++)
                            System.out.println("\t\t"+direcciones[i].toString());
                        
                        InetAddress dir2 = InetAddress.getLocalHost();
                        System.out.println("\tMetodo getLocalHost(): " + dir2);
                            
                        
                    } catch (UnknownHostException e1) {e1.printStackTrace();	  }
                    
                    System.out.println("========================================================");
                break;

                case 2:
                    System.out.println("========================================================");
                    System.out.println("Info URL: ");
                    try {
                        System.out.println("Introduce una direccion web");
                        nombreServidor = sc.next();
                        InetAddress dir = InetAddress.getByName(nombreServidor);
                        System.out.println("\tMetodo getByName():  " + dir);
                        System.out.println("\tMetodo getHostName(): "+ dir.getHostName());
                        System.out.println("\tMetodo getHostAddress(): "+ dir.getHostAddress());
                        System.out.println("\tMetodo toString(): " + dir.toString());
                        System.out.println("\tMetodo getCanonicalHostName(): " + dir.getCanonicalHostName());		
                        
                        // Array de tipo InetAddress con todas las direcciones IP 
                        //asignadas a google.es
                        System.out.println("\tDIRECCIONES IP PARA: " + dir.getHostName());
                        InetAddress[] direcciones = 
                                    InetAddress.getAllByName(dir.getHostName());
                        for (int i = 0; i < direcciones.length; i++)
                            System.out.println("\t\t"+direcciones[i].toString());
                        
                        InetAddress dir2 = InetAddress.getLocalHost();
                        System.out.println("\tMetodo getLocalHost(): " + dir2);
                            
                        
                    } catch (UnknownHostException e1) {e1.printStackTrace();	  }
                    
                    System.out.println("========================================================");

                break;

                case 3:
                    salida = true;
                break;

                default:
                    System.out.println("Has introducido un numero erroneo, introduce los numero que se piden");
                break;
            }
        }

        sc.close();
     }
}
