package Object;

import java.io.*;
import java.net.*;
import java.io.Serializable;

@SuppressWarnings("serial")

public class ObjectTCPServer {
  public static void main(String[] args) throws IOException,
						ClassNotFoundException {
   int numeroPuerto = 6000;// Puerto
   ServerSocket servidor =  new ServerSocket(numeroPuerto);
   System.out.println("Esperando al cliente.....");   
   Socket cliente = servidor.accept();
	
   // Se prepara un flujo de salida para objetos 		
   ObjectOutputStream outObjeto = new ObjectOutputStream(
				cliente.getOutputStream()); 	
   // Se prepara un objeto y se envia 
   Persona per = new Persona("Juan", 20);
   outObjeto.writeObject(per); //enviando objeto
   System.out.println("Envio: " + per.getNombre() +"*"+ per.getEdad());  

   // Se obtiene un stream para leer objetos
   ObjectInputStream inObjeto = new ObjectInputStream(
				cliente.getInputStream());
   Persona dato = (Persona) inObjeto.readObject();
   System.out.println("Recibo: "+dato.getNombre()+"*"+dato.getEdad());
		
   // CERRAR STREAMS Y SOCKETS
   outObjeto.close();
   inObjeto.close();
   cliente.close();
   servidor.close();
  }
}//..

class Persona implements Serializable {
	String nombre;
	int edad;	
	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}	
	public Persona() {super();}

	public String getNombre() {return nombre;}
	public void setNombre(String nombre) {this.nombre = nombre;}
	public int getEdad() {return edad;}
	public void setEdad(int edad) {this.edad = edad;}
}