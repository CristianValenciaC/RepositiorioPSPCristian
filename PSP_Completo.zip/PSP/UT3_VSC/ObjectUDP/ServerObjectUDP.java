package ObjectUDP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerObjectUDP {
    public static void main(String[] args) throws IOException,
						ClassNotFoundException {
   int numeroPuerto = 6000;// Puerto
    DatagramSocket socket = new DatagramSocket(numeroPuerto);

	
   // Se prepara un flujo de salida para objetos
   OutputStream outputStream = cliente.getOutputStream();
    ByteArrayOutputStream baos2 = new ByteArrayOutputStream(); 		
   ObjectOutputStream outObjeto = new ObjectOutputStream(baos2); 	
   // Se prepara un objeto y se envia 
   Persona per = new Persona("Juan", 20);
   outObjeto.writeObject(per); //enviando objeto
   outputStream.write(baos2.toByteArray());
   System.out.println("Envio: " + per.getNombre() +"*"+ per.getEdad());  

   // Se obtiene un stream para leer objetos
   InputStream inputStream = cliente.getInputStream(); 
    ByteArrayOutputStream baos = new ByteArrayOutputStream(); 
    byte[] content = new byte[ 2048 ];  
    int bytesRead = -1;  
    while( ( bytesRead = inputStream.read( content ) ) != -1 ) {  
        baos.write( content, 0, bytesRead );  
    }

    ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());  

    ObjectInputStream perEnt = new ObjectInputStream(bais);
    //Se recibe un objeto
    Persona dato = (Persona) perEnt.readObject();//recibo objeto
    System.out.println("Recibo: "+dato.getNombre()+"*"+dato.getEdad());
		
   // CERRAR STREAMS Y SOCKETS
   outObjeto.close();
   perEnt.close();
   cliente.close();
   servidor.close();
   bais.close();
    baos.close();
    baos2.close();
    outputStream.close();
    inputStream.close();
  }
}
