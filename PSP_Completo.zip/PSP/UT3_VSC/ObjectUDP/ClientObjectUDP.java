package ObjectUDP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;

public class ClientObjectUDP {
    public static void main(String[] arg) throws Exception,
			ClassNotFoundException {
    String Host = "localhost";
    int Puerto = 6000;//puerto remoto	
		
    System.out.println("PROGRAMA CLIENTE INICIADO....");
	
    //Flujo de entrada para objetos
    DatagramSocket cliente = new DatagramSocket();
    byte[] recibidos = new byte[1024];
    DatagramPacket receivePacket = new DatagramPacket(recibidos, recibidos.length);
    cliente.receive(receivePacket);

    byte[] data = receivePacket.getData();
    ByteArrayInputStream in = new ByteArrayInputStream(data);  

    ObjectInputStream perEnt = new ObjectInputStream(in);
    //Se recibe un objeto
    Persona dato = (Persona) perEnt.readObject();//recibo objeto
    System.out.println("Recibo: "+dato.getNombre()+"*"+dato.getEdad());
	
    //Modifico el objeto
    dato.setNombre("Juan Ramos");
    dato.setEdad(22);
	
    //FLUJO DE salida para objetos
    ByteArrayOutputStream baos2 = new ByteArrayOutputStream();	
    ObjectOutputStream perSal = new ObjectOutputStream(baos2);
    // Se envia el objeto
    perSal.writeObject(dato);
    outputStream.write(baos2.toByteArray());
    System.out.println("Envio: "+dato.getNombre()+"*"+dato.getEdad());                       
		
    // CERRAR STREAMS Y SOCKETS
    perEnt.close();
    perSal.close();
    cliente.close();
    bais.close();
    baos.close();
    baos2.close();
    outputStream.close();
    inputStream.close();		
  }
}
