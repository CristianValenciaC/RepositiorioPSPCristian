package ej2_socket;

import java.io.IOException;
import java.net.*;

public class TCPClientSocket1 {
  public static void main(String[] args) {
         String host="192.168.2.213"; //ip conexion servidor
         int puerto=1234;
         byte[] direccion = {(byte)192, (byte)168, (byte)2, (byte)201};
        try 
        {
        InetAddress ipPrueba = InetAddress.getByAddress(direccion);
        Socket Cliente = new Socket(ipPrueba,puerto); //Se crea socket de cliente y lo asocia al puerto indicado del host
        System.out.println("Cliente escuchando en: "+ Cliente.getLocalPort());
        System.out.println("Cliente conectado a puerto remoto: "+ Cliente.getPort());

        InetAddress ip=Cliente.getInetAddress();
        System.out.println("Máquina remota: "+ ip.getHostName().toString());
        System.out.println("IP Máquina remota: "+ ip.getHostAddress().toString());
        
        Cliente.close(); //Cierre del socket

         } catch (IOException excepcion) {excepcion.getMessage()	;  }
  }
  
}
