package ej2_socket;
//  En aplicación cliente/Servidor, el programa servidor se ejecuta en una máquina específica y tiene un socket asociado a un puerto específico
// Clase ServerSocket: sirve para implementar el lado del Servidor
// Se crea un conector en el puerto del servidor que escuchará las peticiones de conexión de los clientes

import java.io.IOException;
import java.net.*;
public class TCPServerSocket1 {

  private static ServerSocket Servidor;

  public static void main(String[] args) {
        int puerto=5555;
        byte[] direccion = {(byte)192, (byte)168, (byte)2, (byte)202};
        try 
        {
        InetAddress ipPrueba = InetAddress.getByAddress(direccion);
        Servidor = new ServerSocket(puerto,1, ipPrueba); //Se crea socket de servidor asociado al puerto
        System.out.println("Servidor escuchando en "+ Servidor.getLocalPort());
        while(true){
          Socket cliente1= Servidor.accept();
          System.out.println("Cliente 1 conectado");
          System.out.println("Ip conectado al servidor: " + cliente1.getInetAddress().getHostAddress());
          System.out.println("Puerto Cliente: " + cliente1.getLocalPort());
        }

         } catch (IOException excepcion) {
          cierreServidor();
          excepcion.getMessage();  
        }
  }
  
  public static void cierreServidor() {
    try {
      Servidor.close();
      System.out.println("El servidor se ha cerrado correctamente");
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.getMessage();
    }
  }

}
