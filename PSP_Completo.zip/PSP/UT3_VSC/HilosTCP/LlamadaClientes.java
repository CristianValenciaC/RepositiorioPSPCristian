package HilosTCP;

public class LlamadaClientes{
    public static void main(String[] args){
        for(int i = 0; i<500; i++){
            SocketCliente cliente = new SocketCliente();
        }
        
    }
}