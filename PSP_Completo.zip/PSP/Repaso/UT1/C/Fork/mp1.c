#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


void main()
{
    pid_t pid;

    pid = fork();

    if (pid == 0)
    {
        printf("Nombre del alumno: %s\n", "Cristian");
    }
    else
    {
        wait(NULL);
        printf("pid del hijo: %d, pid del padre: %d\n", pid, getpid());
    }
    
}