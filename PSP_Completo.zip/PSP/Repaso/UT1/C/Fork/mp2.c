#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void main()
{
    pid_t hijo1;

    hijo1 = fork();

    if (hijo1 == 0)
    {
        /* code */
        pid_t hijo2;
        hijo2 = fork();
        if (hijo2 == 0)
        {
            printf("Soy el proceso P3, mi pid es %d, el pid de mi padre es %d\n", getpid(), getppid());
        }
        else
        {
            wait(NULL);
            printf("Soy el proceso P2, mi pid es %d, el pid de mi padre es %d\n", getpid(), getppid());
        }
        
    }
    else
    {
        wait(NULL);
        printf("Soy el proceso P1, mi pid es %d, el pid de mi hijo es %d\n", getpid(), hijo1);
    }
    

}