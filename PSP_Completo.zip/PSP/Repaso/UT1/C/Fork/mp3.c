#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void main()
{
    pid_t hijo1;

    hijo1 = fork();

    if (hijo1 == 0)
    {
        sleep(10);
        printf("Despierto\n");
    }
    else
    {
        wait(NULL);
        pid_t hijo2;

        hijo2 = fork();

        if (hijo2 == 0)
        {
            printf("Soy el proceso P3, mi pid es %d, el pid de mi padre es %d\n", getpid(), getppid());

        }
        else
        {
            wait(NULL);
        }
        
    }
    
}