#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>


void main()
{
    pid_t hijo;
    int fd[2];
    int buffer1;
    int buffer2;
    int buffer3;
    char buffer4[2];

    pipe(fd);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[1]);
        read(fd[0],&buffer1,sizeof(buffer1));
        read(fd[0],&buffer2,sizeof(buffer2));
        read(fd[0],&buffer3,sizeof(buffer3));
        read(fd[0],&buffer4,sizeof(buffer4));

        printf("Numero a sumar: %d\n", buffer1);
        printf("Numero a sumar: %d\n", buffer2);
        printf("Numero a sumar: %d\n", buffer3);
        printf("Recibido carácter: %s\n", buffer4);
        printf("La suma total es igual a: %d\n", buffer1+buffer2+buffer3);
    }
    else
    {
        close(fd[0]);
        int valores = 10;
        int valores2 = 20;
        int valores3 = 50;
        char caracter = '+';
        write(fd[1], &valores, sizeof(valores));
        write(fd[1], &valores2, sizeof(valores2));
        write(fd[1], &valores3, sizeof(valores3));
        write(fd[1], &caracter, sizeof(caracter));
        wait(NULL);
        /* code */
    }
    
}