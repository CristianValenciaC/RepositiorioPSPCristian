#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void calculodeDosNumeros(int num1, int num2)
{
    printf("%d + %d = %d\n",num1, num2, num1+num2);
    printf("%d - %d = %d\n", num1, num2, num1-num2);
    printf("%d * %d = %d\n", num1, num2, num1*num2);
    printf("%d / %d = %d\n", num1, num2, num1/num2);
}

void main()
{
    pid_t hijo;
    int fd[2];
    int buffer1;
    int buffer2;

    pipe(fd);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[0]);
        srand(time(NULL));
        int valores = rand() % 50 + 1;
        srand(time(NULL)+1);
        int valores2 = rand() % 50 + 1;
        write(fd[1], &valores, sizeof(valores));
        write(fd[1], &valores2, sizeof(valores2));
    }
    else
    {
        close(fd[1]);
        read(fd[0],&buffer1,sizeof(buffer1));
        read(fd[0],&buffer2,sizeof(buffer2));
        calculodeDosNumeros(buffer1, buffer2);
        /* code */
    }
}