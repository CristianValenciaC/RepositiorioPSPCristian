#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void main()
{   
    pid_t hijo;
    int fd[2];
    char buffer[100];

    pipe(fd);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[1]);
        read(fd[0],buffer,100);
        printf("Soy el proceso hijo con pid %d\nFecha/hora: %s", getpid(), buffer);
    }
    else
    {
    time_t hora;
    char *fecha ;
    time(&hora);
    fecha = ctime(&hora);
        close(fd[0]);
        write(fd[1],fecha,100);
        wait(NULL);
        /* code */
    }
    
}