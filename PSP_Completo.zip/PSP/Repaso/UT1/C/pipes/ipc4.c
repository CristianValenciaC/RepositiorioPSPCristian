#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

long factorial(int n)
{
    int c;
    long result = 1;

    for (c = 1; c <= n; c++){
        result = result * c;
    }

    return result;
}

void main()
{
    pid_t hijo;
    int fd[2];
    int fd2[2];
    int buffer1;
    long buffer2;

    pipe(fd);
    pipe(fd2);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[1]);
        close(fd2[0]);
        read(fd[0],&buffer1,sizeof(buffer1));
        long resultado = factorial(buffer1);
        write(fd2[1],&resultado, sizeof(resultado));
    }
    else
    {
        close(fd[0]);
        close(fd2[1]);
        srand(time(NULL));
        int valor = rand() % 10;
        printf("El proceso padre genera el numero %d en el pipe1\n", valor);
        write(fd[1], &valor, sizeof(valor));
        read(fd2[0],&buffer2, sizeof(buffer2));
        printf("El factorial calculado por el proceso hijo: %d != %ld\n", valor, buffer2);

        /* code */
    }
}