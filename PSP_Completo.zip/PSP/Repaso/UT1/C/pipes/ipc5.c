#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

char calcularLetra(int n)
{
    char letra[] = "TRWAGMYFPDXBNJZSQVHLCKE";
    return letra[n/23];
}

void main()
{
    pid_t hijo;
    int fd[2];
    int fd2[2];
    int buffer1;
    char buffer2[2];

    pipe(fd);
    pipe(fd2);

    hijo = fork();

    if (hijo == 0)
    {
        close(fd[0]);
        close(fd2[1]);
        char numDNI[8];
        int DNI;
        int count = 0;
        printf("Introduce un numero de DNI: ");
        while (scanf("%s", numDNI))
        {
            for (size_t i = 0; i < strlen(numDNI); i++)
            {
                if (!isdigit(numDNI[i])){
                    count++;
                }
            }
            


            if (count > 0)
            {
                printf("Número no valido introduzcalo de nuevo");
                printf("Introduce un numero de DNI: ");
                numDNI[0] = '\0';
            }
            else
            {
                exit(0);
            }
        }
                DNI = atoi(numDNI);
                write(fd[1],&DNI,sizeof(DNI));
                read(fd2[0],buffer2, sizeof(buffer2));
                printf("\nLa letra del NIF es: %s\n", buffer2);
                exit(0);
    }
    else
    {
        close(fd[1]);
        close(fd2[0]);
        read(fd[0], &buffer1, sizeof(buffer1));
        char letra = calcularLetra(buffer1);
        write(fd2[1],&letra, sizeof(letra));
        wait(NULL);
        /* code */
    }
}