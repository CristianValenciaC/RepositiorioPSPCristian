#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>

void main()
{
    int fifo, fifo2;

    long buffer;

    fifo = open("FIFO1", 1);
    int numero = rand() % 10;
    write(fifo,&numero,sizeof(numero));
    close(fifo);

    fifo2 = open("FIFO2", 0);
    read(fifo2, &buffer, sizeof(buffer));
    printf("Resultado factorial de %d!: %ld", fifo, buffer);
    close(fifo2);

    remove("FIFO2");
}