#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <fcntl.h>

long factorial(int n)
{
    int c;
    long result = 1;

    for (c = 1; c <= n; c++){
        result = result * c;
    }

    return result;
}

void main()
{
    int fifo, fifo2;

    int buffer;

    fifo = open("FIFO1", 0);
    read(fifo,&buffer,sizeof(buffer));
    close(fifo);

    remove("FIFO1");

    long resultado = factorial(buffer);

    fifo2 = open("FIFO2", 1);
    read(fifo2, &resultado, sizeof(resultado));
    close(fifo2);
}