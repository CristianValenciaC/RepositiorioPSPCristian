#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void main(){
    printf("Nombre del alumno %s", "Cristian");
    system("ls -l /home/");
}