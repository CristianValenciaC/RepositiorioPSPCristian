public class TiendaOnlinesHiloMain {
    
    public static void main(String[] args) {
        //Creamos un objeto de clase HiloCarro con su correspondiente carro
        int carro1[] = {10,20,30,40};
        HiloCarro hilo1 = new HiloCarro("cliente 1 - Cristian", carro1);
        int carro2[] = {15,16};
        HiloCarro hilo2 = new HiloCarro("cliente 2 - Valencia", carro2);
        int carro3[] = {80,70,60,50,40,30,20,10};
        HiloCarro hilo3 = new HiloCarro("cliente 3 - Calvopiña", carro3);

        new Thread(hilo1).start();
        new Thread(hilo2).start();
        new Thread(hilo3).start();
    }

}
